# Lab 8 – Written Answers

## Task 1
**Step 1 (Predict):** I predicted Gentoo is the heaviest species. The chart confirms it (about 5092 g vs about 3706 g for Adelie and 3733 g for Chinstrap).

**Step 5 – Explain it back**
1. **Which line decides how tall each bar is?**
   `.attr("height", d => innerHeight - y(d[1]))` – it converts the value to a pixel position with the y scale and subtracts it from the chart height.
2. **What if `.range([innerHeight, 0])` became `.range([0, innerHeight])`?**
   The y scale would be flipped: 0 would sit at the top and large values at the bottom, so the bars would get shorter as values grow (Gentoo would become the shortest) and the axis would read upside down.
3. **How many `<rect>` elements are on the page, and why?**
   Three, because `d3.rollup` reduces the 333 penguin rows to one row per group (one per species), and `.join("rect")` creates one rectangle for each.

## Task 2 – Debugging (Console / Network / Elements)
*(Write down what you actually see on your machine. These are the results for the typical copy-paste mistake: the second script still has the first script's `const` names and still selects the first `<svg>`.)*

- **Console:** A red `Uncaught SyntaxError: Identifier 'margin' has already been declared` (or `'svg'`). Both scripts declare top-level `const` variables with the same names in the same global scope, so the browser refuses to run the second script.
- **Network:** `d3.v7.min.js` and `penguins.csv` both returned 200, so the files and library loaded correctly. The problem is in my code, not in loading.
- **Elements:** The Console only reported an error. Elements showed that the first `<svg>` has 3 `<rect>`, while the second `<svg>` is empty (0 `<rect>`). It also showed that both `<svg>` elements still had the same id, or that the second script was targeting the first one.
- **Fix:** I wrapped each script in its own function `(function () { ... })();` so the variable names don't clash, gave the SVGs different ids (`chart1`, `chart2`), and made each script select its own id.
