/* Lab 9 - D3.js: treemap, dendrogram, force network, choropleth, point map, combined map */

const DATA = "dataset/";

/* ---------- shared helpers ---------- */

const tooltip = d3.select("#tooltip");

function moveTip(event) {
  const pad = 14;
  const { width, height } = tooltip.node().getBoundingClientRect();
  let x = event.clientX + pad;
  let y = event.clientY + pad;
  if (x + width > window.innerWidth) x = event.clientX - width - pad;
  if (y + height > window.innerHeight) y = event.clientY - height - pad;
  tooltip.style("left", x + "px").style("top", y + "px");
}
function showTip(event, html) {
  tooltip.html(html).style("opacity", 1);
  moveTip(event);
}
function hideTip() {
  tooltip.style("opacity", 0);
}

// CSV rows (department, course, students) -> University > Department > Course
function toHierarchy(rows) {
  const byDept = d3.group(rows, d => d.department);
  return {
    name: "University",
    children: Array.from(byDept, ([dept, items]) => ({
      name: dept,
      children: items.map(r => ({ name: r.course, department: dept, value: r.students }))
    }))
  };
}

const deptColor = d3.scaleOrdinal()
  .domain(["Computer Science", "Engineering", "Business", "Sciences"])
  .range(["#2a6f97", "#d9822b", "#4f8a5b", "#8a5fa8"]);

const fmt = d3.format(",");

/* ---------- Task 1: treemap ---------- */

function drawTreemap(rows) {
  const W = 960, H = 560;
  const svg = d3.select("#treemap").append("svg").attr("viewBox", `0 0 ${W} ${H}`);

  svg.append("text").attr("x", W / 2).attr("y", 24).attr("text-anchor", "middle")
    .attr("font-size", 18).attr("font-weight", 600)
    .text("Course Enrollment by Department (area = number of students)");

  const top = 40, legendH = 34;
  const root = d3.hierarchy(toHierarchy(rows))
    .sum(d => d.value)               // leaves carry value; parents get the sum
    .sort((a, b) => b.value - a.value);

  d3.treemap()
    .size([W, H - top - legendH])
    .paddingOuter(3)
    .paddingTop(d => (d.depth === 1 ? 22 : 3))
    .paddingInner(2)
    .round(true)(root);              // adds x0, y0, x1, y1 to every node

  const g = svg.append("g").attr("transform", `translate(0,${top})`);

  // department containers + headers
  const depts = g.selectAll("g.dept").data(root.children).join("g").attr("class", "dept");
  depts.append("rect")
    .attr("x", d => d.x0).attr("y", d => d.y0)
    .attr("width", d => d.x1 - d.x0).attr("height", d => d.y1 - d.y0)
    .attr("fill", d => deptColor(d.data.name)).attr("fill-opacity", 0.14)
    .attr("stroke", d => deptColor(d.data.name)).attr("stroke-width", 1.5);
  depts.append("text")
    .attr("x", d => d.x0 + 6).attr("y", d => d.y0 + 16)
    .attr("font-size", 13).attr("font-weight", 700)
    .attr("fill", d => d3.color(deptColor(d.data.name)).darker(0.6))
    .text(d => `${d.data.name} (${fmt(d.value)})`);

  // course rectangles
  const leaves = g.selectAll("g.leaf").data(root.leaves()).join("g")
    .attr("class", "leaf")
    .attr("transform", d => `translate(${d.x0},${d.y0})`);

  leaves.append("clipPath").attr("id", (d, i) => `tm-clip-${i}`)
    .append("rect").attr("width", d => d.x1 - d.x0).attr("height", d => d.y1 - d.y0);

  leaves.append("rect")
    .attr("width", d => d.x1 - d.x0).attr("height", d => d.y1 - d.y0)
    .attr("fill", d => deptColor(d.data.department))
    .attr("stroke", "#fff").attr("stroke-width", 1)
    .style("cursor", "default")
    .on("mouseover", function (event, d) {
      d3.select(this).attr("fill", d3.color(deptColor(d.data.department)).brighter(0.5));
      showTip(event, `<b>${d.data.name}</b><br>Department: ${d.data.department}<br>Students: ${fmt(d.value)}`);
    })
    .on("mousemove", moveTip)
    .on("mouseout", function (event, d) {
      d3.select(this).attr("fill", deptColor(d.data.department));
      hideTip();
    });

  leaves.append("text")
    .attr("clip-path", (d, i) => `url(#tm-clip-${i})`)
    .attr("pointer-events", "none")
    .attr("fill", "#fff").attr("font-size", 13)
    .selectAll("tspan")
    .data(d => [d.data.name, fmt(d.value)])
    .join("tspan")
    .attr("x", 7).attr("dy", (t, i) => (i === 0 ? 18 : 16))
    .attr("font-weight", (t, i) => (i === 0 ? 700 : 400))
    .text(t => t);

  // legend (four departments)
  const legend = svg.append("g").attr("transform", `translate(${W / 2 - 250},${H - 22})`);
  deptColor.domain().forEach((name, i) => {
    const item = legend.append("g").attr("transform", `translate(${i * 135},0)`);
    item.append("rect").attr("width", 14).attr("height", 14).attr("rx", 2).attr("fill", deptColor(name));
    item.append("text").attr("x", 20).attr("y", 12).attr("font-size", 12).text(name);
  });
}

/* ---------- Task 2: dendrogram (collapsible) ---------- */

function drawDendrogram(rows) {
  const W = 960, H = 560;
  const margin = { top: 24, right: 150, bottom: 70, left: 110 };
  const innerW = W - margin.left - margin.right;
  const innerH = H - margin.top - margin.bottom;

  const svg = d3.select("#dendrogram").append("svg").attr("viewBox", `0 0 ${W} ${H}`);
  const g = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);

  const root = d3.hierarchy(toHierarchy(rows));
  root.each((d, i) => { d.uid = i; });

  const cluster = d3.cluster().size([innerH, innerW]); // x = vertical spread, y = depth (left to right)
  const depthColor = d3.scaleOrdinal().domain([0, 1, 2]).range(["#1d2733", "#d9822b", "#2a6f97"]);
  const link = d3.linkHorizontal().x(d => d.y).y(d => d.x);
  const isLeaf = d => !d.children && !d._children;

  function update() {
    cluster(root);
    const nodes = root.descendants();
    const links = root.links();

    g.selectAll("path.link")
      .data(links, d => d.target.uid)
      .join(
        enter => enter.append("path").attr("class", "link").attr("fill", "none")
          .attr("stroke", "#9aa5b1").attr("stroke-width", 1.5).attr("d", link),
        update => update,
        exit => exit.remove()
      )
      .transition().duration(400).attr("d", link);

    const node = g.selectAll("g.node")
      .data(nodes, d => d.uid)
      .join(
        enter => {
          const e = enter.append("g").attr("class", "node")
            .attr("transform", d => `translate(${d.y},${d.x})`);
          e.append("circle");
          e.append("text").attr("class", "halo").attr("dy", "0.32em").attr("font-size", 13);
          e.append("title");
          return e;
        },
        update => update,
        exit => exit.remove()
      );

    node.transition().duration(400).attr("transform", d => `translate(${d.y},${d.x})`);

    node.style("cursor", d => (d.depth === 1 ? "pointer" : "default"))
      .on("click", (event, d) => {
        if (d.depth !== 1) return;     // only departments toggle
        if (d.children) { d._children = d.children; d.children = null; }
        else { d.children = d._children; d._children = null; }
        update();
      });

    node.select("circle")
      .attr("r", d => (d._children ? 9 : 7))
      .attr("fill", d => depthColor(d.depth))
      .attr("stroke", d => (d._children ? "#1d2733" : "#fff"))
      .attr("stroke-width", d => (d._children ? 3 : 1.5));

    node.select("text")
      .attr("x", d => (isLeaf(d) ? 12 : -12))                  // leaves right, parents left
      .attr("text-anchor", d => (isLeaf(d) ? "start" : "end"))
      .attr("font-weight", d => (d.depth < 2 ? 700 : 400))
      .text(d => d.data.name + (d._children ? ` (+${d._children.length})` : ""));

    node.select("title").text(d =>
      d.depth === 1 ? "Click to collapse / expand" : d.data.name);
  }

  update();

  // depth legend: its own row under the tree, separated by a thin rule
  svg.append("line").attr("x1", 20).attr("x2", W - 20).attr("y1", H - 48).attr("y2", H - 48)
    .attr("stroke", "#dde2e8");
  const legend = svg.append("g").attr("transform", `translate(${W / 2 - 200},${H - 24})`);
  ["Root", "Department", "Course"].forEach((label, i) => {
    const item = legend.append("g").attr("transform", `translate(${i * 140},0)`);
    item.append("circle").attr("cx", 7).attr("cy", 0).attr("r", 7).attr("fill", depthColor(i));
    item.append("text").attr("x", 22).attr("dy", "0.32em").attr("font-size", 13).text(label);
  });
}

/* ---------- Task 3: force-directed flight network ---------- */

function drawNetwork(edges) {
  const W = 960, H = 600;
  const svg = d3.select("#network").append("svg").attr("viewBox", `0 0 ${W} ${H}`);

  // node list built from the edge list: unique city names + degree
  const names = Array.from(new Set(edges.flatMap(e => [e.source, e.target])));
  const nodes = names.map(id => ({
    id,
    degree: edges.filter(e => e.source === id || e.target === id).length,
    total: d3.sum(edges.filter(e => e.source === id || e.target === id), e => e.flights)
  }));
  const links = edges.map(e => ({ source: e.source, target: e.target, flights: e.flights }));

  const widthScale = d3.scaleLinear().domain(d3.extent(links, d => d.flights)).range([1.5, 11]);
  const radiusScale = d3.scaleSqrt().domain(d3.extent(nodes, d => d.degree)).range([9, 28]);

  const linkSel = svg.append("g").attr("stroke", "#7f8c9a").attr("stroke-linecap", "round")
    .selectAll("line").data(links).join("line")
    .attr("stroke-width", d => widthScale(d.flights))
    .attr("stroke-opacity", 0.6);

  linkSel
    .on("mouseover", (event, d) =>
      showTip(event, `<b>${d.source.id} - ${d.target.id}</b><br>${d.flights} flights per week`))
    .on("mousemove", moveTip)
    .on("mouseout", hideTip);

  const nodeSel = svg.append("g").selectAll("g").data(nodes).join("g").style("cursor", "grab");
  nodeSel.append("circle")
    .attr("r", d => radiusScale(d.degree))
    .attr("fill", "#2a6f97").attr("stroke", "#fff").attr("stroke-width", 2);
  nodeSel.append("text")
    .attr("class", "halo").attr("text-anchor", "middle").attr("font-size", 12).attr("font-weight", 600)
    .attr("dy", d => radiusScale(d.degree) + 14)
    .text(d => d.id);

  const sim = d3.forceSimulation(nodes)
    .force("link", d3.forceLink(links).id(d => d.id).distance(130))
    .force("charge", d3.forceManyBody().strength(-450))
    .force("center", d3.forceCenter(W / 2, H / 2))
    .force("collide", d3.forceCollide(d => radiusScale(d.degree) + 18))
    .on("tick", () => {
      nodes.forEach(d => {            // keep nodes inside the canvas
        const r = radiusScale(d.degree) + 4;
        d.x = Math.max(r, Math.min(W - r, d.x));
        d.y = Math.max(r, Math.min(H - r - 14, d.y));
      });
      linkSel.attr("x1", d => d.source.x).attr("y1", d => d.source.y)
        .attr("x2", d => d.target.x).attr("y2", d => d.target.y);
      nodeSel.attr("transform", d => `translate(${d.x},${d.y})`);
    });

  nodeSel.call(d3.drag()
    .on("start", (event, d) => {
      if (!event.active) sim.alphaTarget(0.3).restart();
      d.fx = d.x; d.fy = d.y;
    })
    .on("drag", (event, d) => { d.fx = event.x; d.fy = event.y; })
    .on("end", (event, d) => {
      if (!event.active) sim.alphaTarget(0);
      d.fx = null; d.fy = null;
    }));

  // hover: highlight this city's routes, fade the rest
  const linked = (l, n) => l.source.id === n.id || l.target.id === n.id;
  nodeSel
    .on("mouseover", (event, n) => {
      linkSel.attr("stroke-opacity", l => (linked(l, n) ? 0.95 : 0.08))
        .attr("stroke", l => (linked(l, n) ? "#d9822b" : "#7f8c9a"));
      const neighbours = new Set(links.filter(l => linked(l, n))
        .flatMap(l => [l.source.id, l.target.id]));
      nodeSel.attr("opacity", d => (neighbours.has(d.id) ? 1 : 0.2));
      showTip(event, `<b>${n.id}</b><br>${n.degree} routes<br>${n.total} flights per week`);
    })
    .on("mousemove", moveTip)
    .on("mouseout", () => {
      linkSel.attr("stroke-opacity", 0.6).attr("stroke", "#7f8c9a");
      nodeSel.attr("opacity", 1);
      hideTip();
    });

  // legend
  const lg = svg.append("g").attr("transform", "translate(20,20)");
  lg.append("text").attr("font-size", 12).attr("font-weight", 700).text("Link width = flights per week");
  const sample = d3.extent(links, d => d.flights);
  [sample[0], Math.round((sample[0] + sample[1]) / 2), sample[1]].forEach((v, i) => {
    lg.append("line").attr("x1", 0).attr("x2", 40).attr("y1", 20 + i * 18).attr("y2", 20 + i * 18)
      .attr("stroke", "#7f8c9a").attr("stroke-width", widthScale(v)).attr("stroke-linecap", "round");
    lg.append("text").attr("x", 50).attr("y", 24 + i * 18).attr("font-size", 12).text(v);
  });
  lg.append("text").attr("y", 86).attr("font-size", 12).attr("font-weight", 700).text("Node size = number of routes");
}

/* ---------- Task 4: world population choropleth ---------- */

function drawChoropleth(world, population) {
  const W = 960, H = 520;
  const svg = d3.select("#choropleth").append("svg").attr("viewBox", `0 0 ${W} ${H}`);

  const popById = new Map(population.map(d => [d.id, d]));       // join key = country code
  const [minPop, maxPop] = d3.extent(population, d => d.population_millions);
  // one hue (blue): light to dark. Starting at 0.25 keeps the smallest country distinguishable from "no data" gray
  const interp = t => d3.interpolateBlues(0.25 + 0.75 * t);
  const color = d3.scaleSequentialSqrt(interp).domain([minPop, maxPop]);
  const noData = "#d9d9d9";

  const land = { type: "FeatureCollection", features: world.features.filter(f => f.properties.name !== "Antarctica") };
  const projection = d3.geoNaturalEarth1().fitExtent([[10, 40], [W - 10, H - 60]], land);
  const path = d3.geoPath(projection);

  svg.append("text").attr("x", W / 2).attr("y", 26).attr("text-anchor", "middle")
    .attr("font-size", 18).attr("font-weight", 600).text("World Population (millions)");

  svg.append("path").attr("d", path({ type: "Sphere" })).attr("fill", "#eef5fa").attr("stroke", "#c9d6e0");

  const countries = svg.append("g").selectAll("path").data(land.features).join("path")
    .attr("d", path)
    .attr("fill", d => (popById.has(d.id) ? color(popById.get(d.id).population_millions) : noData))
    .attr("stroke", "#fff").attr("stroke-width", 0.5);

  // thin outline drawn on top of the hovered country (the country itself is never restyled)
  const outline = svg.append("path").attr("fill", "none").attr("stroke", "#1d2733")
    .attr("stroke-width", 1.5).attr("stroke-linejoin", "round")
    .attr("pointer-events", "none").style("display", "none");

  countries
    .on("mouseover", (event, d) => {
      outline.attr("d", path(d)).style("display", null);
      const rec = popById.get(d.id);
      showTip(event, `<b>${d.properties.name}</b><br>` +
        (rec ? `Population: ${fmt(rec.population_millions)} million` : "No data"));
    })
    .on("mousemove", moveTip)
    .on("mouseleave", () => {
      outline.style("display", "none");
      hideTip();
    });

  // legend: gradient bar with min and max labels
  const lw = 300, lx = 80, ly = H - 36;
  const defs = svg.append("defs");
  const grad = defs.append("linearGradient").attr("id", "pop-gradient");
  d3.range(0, 1.001, 0.1).forEach(t => grad.append("stop").attr("offset", `${t * 100}%`).attr("stop-color", interp(t)));

  const legend = svg.append("g").attr("transform", `translate(${lx},${ly})`);
  legend.append("rect").attr("width", lw).attr("height", 12).attr("fill", "url(#pop-gradient)");
  const legendScale = d3.scaleSqrt().domain([minPop, maxPop]).range([0, lw]);
  const ticks = [minPop, 250, 500, 1000, maxPop];
  legend.append("g").attr("transform", "translate(0,12)")
    .call(d3.axisBottom(legendScale).tickValues(ticks).tickSize(4)
      .tickFormat(d => (d === minPop ? `${d}M (min)` : d === maxPop ? `${fmt(d)}M (max)` : `${d}M`)))
    .call(g => g.select(".domain").remove())
    .selectAll("text").attr("font-size", 11);
  legend.append("text").attr("y", -6).attr("font-size", 12).attr("font-weight", 600)
    .text("Population (square-root scale)");

  const gray = svg.append("g").attr("transform", `translate(${lx + lw + 90},${ly})`);
  gray.append("rect").attr("width", 14).attr("height", 12).attr("fill", noData);
  gray.append("text").attr("x", 20).attr("y", 11).attr("font-size", 12).text("No data");
}

/* ---------- shared pieces for the Pakistan maps ---------- */

const PK_W = 800, PK_H = 740;

// a few cities sit right next to a bigger neighbour, so their label goes on the left
const LABEL_LEFT = new Set(["Peshawar", "Faisalabad"]);
function labelAttrs(sel, r) {
  return sel
    .attr("text-anchor", d => (LABEL_LEFT.has(d.name) ? "end" : "start"))
    .attr("x", d => (LABEL_LEFT.has(d.name) ? -1 : 1) * (r(d) + 5));
}

function pakistanProjection() {
  return d3.geoMercator().center([69.5, 30.3]).scale(2250).translate([PK_W / 2, PK_H / 2]);
}

// nested-circle size legend: circles share one baseline, each label sits level with its circle's top
function sizeLegend(g, radius, values, cx, top) {
  const sorted = values.slice().sort((a, b) => b - a);
  const R = radius(sorted[0]);
  const base = top + 2 * R;
  sorted.forEach(v => {
    const r = radius(v);
    g.append("circle").attr("cx", cx).attr("cy", base - r).attr("r", r)
      .attr("fill", "#8a95a1").attr("fill-opacity", 0.25).attr("stroke", "#6b7682");
    g.append("line").attr("x1", cx).attr("x2", cx + R + 10).attr("y1", base - 2 * r).attr("y2", base - 2 * r)
      .attr("stroke", "#6b7682").attr("stroke-width", 0.8);
    g.append("text").attr("x", cx + R + 14).attr("y", base - 2 * r + 4).attr("font-size", 11).text(`${v}M`);
  });
  return base;
}

function drawPakistanBase(svg, world, projection) {
  const path = d3.geoPath(projection);
  svg.append("rect").attr("width", PK_W).attr("height", PK_H).attr("fill", "#eef5fa");
  svg.append("g").selectAll("path").data(world.features).join("path")
    .attr("d", path)
    .attr("fill", d => (d.id === "PAK" ? "#f7f1e1" : "#e4e7ea"))
    .attr("stroke", d => (d.id === "PAK" ? "#8c7a4b" : "#fff"))
    .attr("stroke-width", d => (d.id === "PAK" ? 1.4 : 0.8));

  // light context labels for the neighbours
  [["INDIA", 76.5, 27.5], ["CHINA", 78, 36.5], ["AFGHANISTAN", 65.5, 35.5], ["IRAN", 60.4, 29.5],
    ["Arabian Sea", 65.5, 23.6]].forEach(([name, lon, lat]) => {
    const [x, y] = projection([lon, lat]);
    svg.append("text").attr("x", x).attr("y", y).attr("text-anchor", "middle")
      .attr("font-size", 12).attr("letter-spacing", 1.5).attr("fill", "#a1a9b1")
      .attr("font-style", name === "Arabian Sea" ? "italic" : "normal").text(name);
  });
}

/* ---------- Task 5: Pakistan point map ---------- */

function drawPointMap(world, cities) {
  const svg = d3.select("#pointmap").append("svg").attr("viewBox", `0 0 ${PK_W} ${PK_H}`);
  const projection = pakistanProjection();
  drawPakistanBase(svg, world, projection);

  const radius = d3.scaleSqrt().domain([0, d3.max(cities, d => d.pop)]).range([0, 42]); // area ~ population

  svg.append("text").attr("x", PK_W / 2).attr("y", 30).attr("text-anchor", "middle")
    .attr("font-size", 18).attr("font-weight", 600).text("Largest Cities of Pakistan (circle area = population)");

  // biggest first so small cities sit on top and stay hoverable
  const sorted = cities.slice().sort((a, b) => b.pop - a.pop);
  const dots = svg.append("g").selectAll("circle").data(sorted).join("circle")
    .attr("cx", d => projection([d.lon, d.lat])[0])      // longitude first
    .attr("cy", d => projection([d.lon, d.lat])[1])
    .attr("r", d => Math.max(2.5, radius(d.pop)))
    .attr("fill", "#c0392b").attr("fill-opacity", 0.45)
    .attr("stroke", "#8e2a20").attr("stroke-width", 1);

  dots
    .on("mouseover", function (event, d) {
      d3.select(this).attr("fill-opacity", 0.8).attr("stroke-width", 2);
      showTip(event, `<b>${d.name}</b><br>Population: ${d.pop} million`);
    })
    .on("mousemove", moveTip)
    .on("mouseout", function () {
      d3.select(this).attr("fill-opacity", 0.45).attr("stroke-width", 1);
      hideTip();
    });

  // labels only for cities above 1 million
  svg.append("g").selectAll("text").data(sorted.filter(d => d.pop > 1)).join("text")
    .attr("class", "halo").attr("pointer-events", "none")
    .attr("transform", d => `translate(${projection([d.lon, d.lat])})`)
    .attr("y", 4)
    .attr("font-size", 13).attr("font-weight", 600)
    .text(d => d.name)
    .call(sel => labelAttrs(sel, d => Math.max(2.5, radius(d.pop))));

  // size legend
  const lg = svg.append("g").attr("transform", `translate(${PK_W - 165},${PK_H - 175})`);
  lg.append("rect").attr("x", -12).attr("y", -16).attr("width", 168).attr("height", 134).attr("rx", 8)
    .attr("fill", "#fff").attr("fill-opacity", 0.92).attr("stroke", "#c9d2da");
  lg.append("text").attr("font-size", 12).attr("font-weight", 700).text("Population (millions)");
  sizeLegend(lg, radius, [1, 5, 15], 42, 14);
}

/* ---------- Task 6: combined spatial encoding map ---------- */

function drawCombinedMap(world, cities, flights) {
  const svg = d3.select("#combined").append("svg").attr("viewBox", `0 0 ${PK_W} ${PK_H}`);
  const projection = pakistanProjection();
  drawPakistanBase(svg, world, projection);

  svg.append("text").attr("x", PK_W / 2).attr("y", 30).attr("text-anchor", "middle")
    .attr("font-size", 18).attr("font-weight", 600).text("Pakistan: Cities and Weekly Flight Routes");

  // match each route's source/target to the city coordinates
  const cityByName = new Map(cities.map(c => {
    const [x, y] = projection([c.lon, c.lat]);
    return [c.name, { ...c, x, y }];
  }));
  const routes = flights
    .map(f => ({ ...f, a: cityByName.get(f.source), b: cityByName.get(f.target) }))
    .filter(r => r.a && r.b);

  // degree decides "hub" (4 or more routes)
  const degree = new Map(cities.map(c => [c.name, 0]));
  routes.forEach(r => {
    degree.set(r.source, degree.get(r.source) + 1);
    degree.set(r.target, degree.get(r.target) + 1);
  });
  const cityList = Array.from(cityByName.values()).map(c => ({ ...c, degree: degree.get(c.name), hub: degree.get(c.name) >= 4 }));

  const radius = d3.scaleSqrt().domain([0, d3.max(cities, d => d.pop)]).range([0, 38]);
  const widthScale = d3.scaleLinear().domain(d3.extent(routes, d => d.flights)).range([1.2, 9]);
  const hubColor = "#d9822b", normalColor = "#2a6f97";

  // routes first (drawn underneath), as gentle arcs
  const arc = r => {
    const mx = (r.a.x + r.b.x) / 2, my = (r.a.y + r.b.y) / 2;
    const dx = r.b.x - r.a.x, dy = r.b.y - r.a.y;
    const bend = 0.12;                                  // perpendicular offset for the control point
    return `M${r.a.x},${r.a.y}Q${mx - dy * bend},${my + dx * bend} ${r.b.x},${r.b.y}`;
  };
  const routeSel = svg.append("g").attr("fill", "none").attr("stroke-linecap", "round")
    .selectAll("path").data(routes).join("path")
    .attr("d", arc)
    .attr("stroke", "#4a5563").attr("stroke-opacity", 0.55)
    .attr("stroke-width", d => widthScale(d.flights))
    .on("mouseover", (event, d) =>
      showTip(event, `<b>${d.source} - ${d.target}</b><br>${d.flights} flights per week`))
    .on("mousemove", moveTip)
    .on("mouseout", hideTip);

  // cities on top, largest first so small ones remain visible
  const sorted = cityList.slice().sort((a, b) => b.pop - a.pop);
  const cityG = svg.append("g").selectAll("g").data(sorted).join("g")
    .attr("transform", d => `translate(${d.x},${d.y})`);
  cityG.append("circle")
    .attr("r", d => Math.max(3, radius(d.pop)))
    .attr("fill", d => (d.hub ? hubColor : normalColor)).attr("fill-opacity", 0.7)
    .attr("stroke", "#fff").attr("stroke-width", 1.5);
  cityG.append("text").attr("class", "halo").attr("pointer-events", "none")
    .attr("y", 4)
    .attr("font-size", 12).attr("font-weight", 600).text(d => d.name)
    .call(sel => labelAttrs(sel, d => Math.max(3, radius(d.pop))));

  // hover: highlight this city's routes, dim everything else
  cityG
    .on("mouseover", (event, c) => {
      const mine = r => r.source === c.name || r.target === c.name;
      const touching = new Set(routes.filter(mine).flatMap(r => [r.source, r.target]));
      routeSel.attr("stroke-opacity", r => (mine(r) ? 0.95 : 0.06))
        .attr("stroke", r => (mine(r) ? "#c0392b" : "#4a5563"));
      cityG.attr("opacity", d => (touching.has(d.name) || d.name === c.name ? 1 : 0.2));
      showTip(event, `<b>${c.name}</b><br>Population: ${c.pop} million<br>Routes: ${c.degree}${c.hub ? " (hub)" : ""}`);
    })
    .on("mousemove", moveTip)
    .on("mouseout", () => {
      routeSel.attr("stroke-opacity", 0.55).attr("stroke", "#4a5563");
      cityG.attr("opacity", 1);
      hideTip();
    });

  // legend covering all four encodings, stacked in one panel
  const lg = svg.append("g").attr("transform", `translate(${PK_W - 236},${PK_H - 292})`);
  lg.append("rect").attr("x", -12).attr("y", -16).attr("width", 232).attr("height", 284).attr("rx", 8)
    .attr("fill", "#fff").attr("fill-opacity", 0.92).attr("stroke", "#c9d2da");

  lg.append("text").attr("font-size", 12).attr("font-weight", 700).text("Position");
  lg.append("text").attr("y", 15).attr("font-size", 11).attr("fill", "#5f6b7a").text("real longitude and latitude");

  lg.append("text").attr("y", 42).attr("font-size", 12).attr("font-weight", 700).text("Circle size = population");
  const base = sizeLegend(lg, radius, [1, 5, 15], 40, 52);

  const cy = base + 26;
  lg.append("text").attr("y", cy).attr("font-size", 12).attr("font-weight", 700).text("Color");
  [[hubColor, "Hub (4 or more routes)"], [normalColor, "Not a hub"]].forEach(([c, label], i) => {
    lg.append("circle").attr("cx", 8).attr("cy", cy + 16 + i * 18).attr("r", 6).attr("fill", c).attr("fill-opacity", 0.7);
    lg.append("text").attr("x", 22).attr("y", cy + 20 + i * 18).attr("font-size", 11).text(label);
  });

  const ly2 = cy + 62;
  lg.append("text").attr("y", ly2).attr("font-size", 12).attr("font-weight", 700).text("Line width = flights per week");
  const ext = d3.extent(routes, d => d.flights);
  ext.forEach((v, i) => {
    const x0 = i * 100;
    lg.append("line").attr("x1", x0).attr("x2", x0 + 34).attr("y1", ly2 + 18).attr("y2", ly2 + 18)
      .attr("stroke", "#4a5563").attr("stroke-width", widthScale(v)).attr("stroke-linecap", "round");
    lg.append("text").attr("x", x0 + 40).attr("y", ly2 + 22).attr("font-size", 11).text(v);
  });
}

/* ---------- load everything, then draw ---------- */

Promise.all([
  d3.csv(DATA + "university.csv", d3.autoType),
  d3.csv(DATA + "flights.csv", d3.autoType),
  d3.csv(DATA + "population.csv", d3.autoType),
  d3.csv(DATA + "pakistan_cities.csv", d3.autoType),
  d3.json(DATA + "world.geojson")
]).then(([university, flights, population, cities, world]) => {
  drawTreemap(university);
  drawDendrogram(university);
  drawNetwork(flights);
  drawChoropleth(world, population);
  drawPointMap(world, cities);
  drawCombinedMap(world, cities, flights);
}).catch(err => {
  console.error(err);
  const box = document.getElementById("error");
  box.hidden = false;
  box.textContent = "Could not load the data files. Open this page through a local server " +
    "(for example VS Code Live Server) and keep the dataset/ folder next to index.html. (" + err.message + ")";
});
