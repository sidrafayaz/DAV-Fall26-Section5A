# AI use declaration — Assignment 1 (Q1 and Q2)

**Student:** Shoaib Hassan · **Roll:** 24i-2546 · **Section:** DS-5A

## Tools used

| Tool | Used for |
|---|---|
| **Claude (Anthropic), Opus model, agentic mode with a Python sandbox** | Drafting and running both notebooks end-to-end; exploring the raw data; writing plotting code; drafting the markdown explanations and the board memo; building the memo PDF (reportlab, outside the notebook) |

No other AI tool was used.

## What the AI was used for, step by step

### Q1 — QuickBite
1. **Data audit (Part A).** Profiling `orders.csv` to find the data-quality problems:
   - exact duplicate rows;
   - 14 city spellings;
   - order values in paisa;
   - the 999 placeholder and negative delivery times;
   - rating = 0 from iOS 4.8.3;
   - ISO/UTC timestamps for Karachi between 1 Sep and 15 Oct 2025;
   - pile-ups at prep = 4.0 min and distance = 18 km;
   - orders dated before a rider's `joined_on`.
2. **Choosing fixes.** For each problem, the AI proposed correct / flag / drop. The evidence for each choice is computed in the notebook (discount-to-basket ratio for the paisa rows, ECDF overlap for the negative times, the hour-profile correlation at each shift for the timestamps).
3. **Statistical checks.** Confidence intervals (Welch, Wilson), STL decomposition, regressions with fixed effects (promo × city; rider fatigue with hour/city/weekday/month controls), the hinge model for rain, and a control chart for the app incident.
4. **Chart code and redesigns** for Parts B–G, plus the Plotly bonus view.
5. **Drafting the findings text and the memo.**

### Q2 — Chart Clinic
1. **Designing the simulated dataset** (smooth seasonal waves, seed 2546) so that all six card rules pass. `check_my_data` passed R1–R6 on the first full run.
2. **Code for the broken dashboard, the fixes and the final dashboard.** Every colour-blindness, contrast and data check uses only the provided helper functions.
3. **Drafting the write-ups and the director's report.**

## What was changed or rejected from the AI's first outputs
- **Ramadan title rejected.** The first title on the iftar chart said lateness "peaks right after iftar". The numbers did not support this (+0.48 min vs other Ramadan hours, +0.22 min vs the same clock window, CI including 0), so the title was rewritten to state that the first 90 minutes are *not* the worst.
- **Pareto chart replaced.** The first version used a twin-axis Pareto chart, which would contradict the Part F critique of dual axes. It was replaced by top-10% / top-20% bars by city.
- **Negative-delivery-time justification reworded.** The first log said "KS p > 0.05", which was wrong (p = 0.03). The justification now reports the KS D statistic and the medians instead.
- **Change-point rule tightened.** The first control-chart rule flagged a single noisy day in January. It was changed to require at least 3 consecutive days above the limit, which gives 10 April – 13 May.
- **Rain threshold softened.** The rain title first claimed "no effect below ~15 mm". The hinge model gave about 7 mm, so the text now gives both and calls the practical threshold 10–15 mm.
- **Hard-coded numbers removed.** Several figure titles had numbers typed in (e.g. "73% of volume", "1 in 8", "3–5×"). They are now computed from the data, and the fog ratio turned out to be 4–6×.
- **Q2 highlight colour darkened.** In greyscale, orange #da570b and grey #8C8C8C had almost the same lightness, so the highlight was darkened to #b84a0a.
- **Q2 status palette changed.** The first status palette was "risky" in greyscale (ΔE 7.1). It was changed to one where every view is "distinguishable" (minimum ΔE 12).
- **Layout fixes.** Several figures had overlapping labels and captions (missingness matrix, Simpson dot plot, DAG, product slide). These were repositioned.

## Verification
- Every number in the markdown, the memo and the Q2 report was checked against the printed notebook output. The memo's numbers are collected in one table at the end of Part G of `q1_analysis.ipynb`.
- Both notebooks were re-run top to bottom (Restart & Run All) from a clean copy of the submission folder.
- `chart_clinic_helpers.py` is byte-identical to the provided file (checked with an MD5 hash).

## Student's own review notes
<!-- Add here anything you changed yourself after reviewing, and make sure you can explain every cell for the viva. -->
