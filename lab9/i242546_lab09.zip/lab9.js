const tooltip = d3.select("#tooltip");
function showTip(event, html) {
  tooltip.html(html).style("opacity", 1)
    .style("left", (event.pageX + 12) + "px")
    .style("top", (event.pageY - 28) + "px");
}
function hideTip() { tooltip.style("opacity", 0); }

Promise.all([
  d3.csv("dataset/university.csv", d3.autoType),
  d3.csv("dataset/flights.csv", d3.autoType),
  d3.csv("dataset/population.csv", d3.autoType),
  d3.csv("dataset/pakistan_cities.csv", d3.autoType),
  d3.json("dataset/world.geojson")
]).then(([university, flights, population, cities, world]) => {
  task1(university);
  task2(university);
  task3(flights);
  task4(population, world);
  task5(cities, world);
  task6(cities, flights, world);
}).catch(err => console.error("Data loading failed:", err));

/* ---------- shared: flat rows -> hierarchy (University > Department > Course) ---------- */
function buildHierarchyData(rows) {
  const grouped = d3.group(rows, d => d.department);
  return {
    name: "University",
    children: Array.from(grouped, ([dept, items]) => ({
      name: dept,
      children: items.map(r => ({ name: r.course, value: r.students }))
    }))
  };
}

/* ---------- Task 1: Treemap ---------- */
function task1(rows) {
  const width = 900, height = 520, top = 40;
  const svg = d3.select("#t1").append("svg").attr("width", width).attr("height", height + top + 40);

  svg.append("text").attr("x", width / 2).attr("y", 25).attr("text-anchor", "middle")
    .attr("font-size", 18).attr("font-weight", "bold").text("Course Enrollment by Department (area = number of students)");

  const root = d3.hierarchy(buildHierarchyData(rows)).sum(d => d.value).sort((a, b) => b.value - a.value);
  d3.treemap().size([width, height]).paddingInner(2).paddingTop(0).round(true)(root);

  const depts = root.children.map(d => d.data.name);
  const color = d3.scaleOrdinal().domain(depts).range(d3.schemeTableau10);

  const g = svg.append("g").attr("transform", `translate(0,${top})`);
  const leaf = g.selectAll("g").data(root.leaves()).join("g")
    .attr("transform", d => `translate(${d.x0},${d.y0})`);

  leaf.append("rect")
    .attr("width", d => d.x1 - d.x0).attr("height", d => d.y1 - d.y0)
    .attr("fill", d => color(d.parent.data.name)).attr("stroke", "#fff")
    .on("mousemove", (event, d) => showTip(event,
      `<b>${d.data.name}</b><br>Department: ${d.parent.data.name}<br>Students: ${d.value}`))
    .on("mouseout", hideTip);

  leaf.append("clipPath").attr("id", (d, i) => `clip-${i}`).append("rect")
    .attr("width", d => d.x1 - d.x0).attr("height", d => d.y1 - d.y0);
  leaf.append("text").attr("x", 6).attr("y", 18).attr("fill", "#fff").attr("font-size", 13)
    .attr("clip-path", (d, i) => `url(#clip-${i})`)
    .attr("pointer-events", "none").text(d => d.data.name);

  // legend
  const legend = svg.append("g").attr("transform", `translate(${width / 2 - depts.length * 75},${height + top + 15})`);
  depts.forEach((dpt, i) => {
    const item = legend.append("g").attr("transform", `translate(${i * 150},0)`);
    item.append("rect").attr("width", 14).attr("height", 14).attr("fill", color(dpt));
    item.append("text").attr("x", 20).attr("y", 12).attr("font-size", 13).text(dpt);
  });
}

/* ---------- Task 2: Dendrogram ---------- */
function task2(rows) {
  const width = 900, height = 520, margin = { top: 20, right: 170, bottom: 20, left: 130 };
  const svg = d3.select("#t2").append("svg").attr("width", width).attr("height", height);
  const g = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);

  const root = d3.hierarchy(buildHierarchyData(rows));
  root.each(d => { d._children = d.children; });
  const cluster = d3.cluster().size([height - margin.top - margin.bottom, width - margin.left - margin.right]);
  const color = d3.scaleOrdinal().domain([0, 1, 2]).range(["#1f77b4", "#ff7f0e", "#2ca02c"]);
  const linkGen = d3.linkHorizontal().x(d => d.y).y(d => d.x);

  // depth legend
  const names = ["Root (University)", "Department", "Course"];
  const lg = svg.append("g").attr("transform", `translate(10,10)`);
  names.forEach((n, i) => {
    lg.append("circle").attr("cx", 6).attr("cy", i * 20).attr("r", 6).attr("fill", color(i));
    lg.append("text").attr("x", 18).attr("y", i * 20 + 4).attr("font-size", 12).text(n);
  });

  function update() {
    cluster(root);
    const t = d3.transition().duration(500);

    g.selectAll("path.link").data(root.links(), d => d.target.data.name)
      .join(
        enter => enter.append("path").attr("class", "link").attr("fill", "none")
          .attr("stroke", "#999").attr("stroke-width", 1.5).attr("d", linkGen),
        update => update,
        exit => exit.remove()
      ).transition(t).attr("d", linkGen);

    const nodes = g.selectAll("g.node").data(root.descendants(), d => d.data.name)
      .join(
        enter => {
          const n = enter.append("g").attr("class", "node")
            .attr("transform", d => `translate(${d.y},${d.x})`);
          n.append("circle").attr("r", 7).attr("fill", d => color(d.depth)).attr("stroke", "#fff").attr("stroke-width", 1.5);
          n.append("text").attr("dy", "0.32em").attr("font-size", 13);
          return n;
        },
        update => update,
        exit => exit.remove()
      );

    nodes.style("cursor", d => d.depth === 1 ? "pointer" : "default")
      .on("click", (event, d) => {
        if (d.depth !== 1) return;
        d.children = d.children ? null : d._children;
        update();
      })
      .transition(t).attr("transform", d => `translate(${d.y},${d.x})`);

    // leaves (no children and a course) -> label on right; parents -> label on left
    nodes.select("text")
      .attr("x", d => d.depth === 2 ? 12 : -12)
      .attr("y", d => d.depth === 2 ? 0 : -14)
      .attr("text-anchor", d => d.depth === 2 ? "start" : "end")
      .text(d => d.data.name + (d.depth === 1 && !d.children ? " (+)" : ""));
  }
  update();
}

/* ---------- Task 3: Force-directed flight network ---------- */
function buildGraph(flights) {
  const names = new Set();
  flights.forEach(f => { names.add(f.source); names.add(f.target); });
  const nodes = Array.from(names, id => ({ id, degree: 0 }));
  const byId = new Map(nodes.map(n => [n.id, n]));
  const links = flights.map(f => ({ source: f.source, target: f.target, flights: f.flights }));
  links.forEach(l => { byId.get(l.source).degree++; byId.get(l.target).degree++; });
  return { nodes, links };
}

function task3(flights) {
  const width = 900, height = 600;
  const { nodes, links } = buildGraph(flights);
  const svg = d3.select("#t3").append("svg").attr("width", width).attr("height", height);

  const widthScale = d3.scaleLinear().domain(d3.extent(links, d => d.flights)).range([1.5, 12]);
  const rScale = d3.scaleSqrt().domain([0, d3.max(nodes, d => d.degree)]).range([6, 32]);

  const sim = d3.forceSimulation(nodes)
    .force("link", d3.forceLink(links).id(d => d.id).distance(140))
    .force("charge", d3.forceManyBody().strength(-500))
    .force("center", d3.forceCenter(width / 2, height / 2))
    .force("collide", d3.forceCollide(d => rScale(d.degree) + 8));

  const link = svg.append("g").attr("stroke", "#888").attr("stroke-opacity", 0.7)
    .selectAll("line").data(links).join("line").attr("stroke-width", d => widthScale(d.flights));

  link.append("title").text(d => `${d.source.id ?? d.source} - ${d.target.id ?? d.target}: ${d.flights} flights/week`);

  const node = svg.append("g").selectAll("g").data(nodes).join("g").style("cursor", "grab")
    .call(d3.drag()
      .on("start", (event, d) => { if (!event.active) sim.alphaTarget(0.3).restart(); d.fx = d.x; d.fy = d.y; })
      .on("drag", (event, d) => { d.fx = event.x; d.fy = event.y; })
      .on("end", (event, d) => { if (!event.active) sim.alphaTarget(0); d.fx = null; d.fy = null; }));

  node.append("circle").attr("r", d => rScale(d.degree)).attr("fill", "#4e79a7").attr("stroke", "#fff").attr("stroke-width", 2);
  node.append("text").attr("text-anchor", "middle").attr("dy", d => -rScale(d.degree) - 5)
    .attr("font-size", 13).attr("pointer-events", "none").text(d => d.id);

  node.on("mouseover", (event, d) => {
      link.attr("stroke-opacity", l => (l.source === d || l.target === d) ? 1 : 0.08)
          .attr("stroke", l => (l.source === d || l.target === d) ? "#e15759" : "#888");
      const connected = new Set([d.id]);
      links.forEach(l => { if (l.source === d) connected.add(l.target.id); if (l.target === d) connected.add(l.source.id); });
      node.attr("opacity", n => connected.has(n.id) ? 1 : 0.15);
      showTip(event, `<b>${d.id}</b><br>Routes: ${d.degree}`);
    })
    .on("mousemove", (event, d) => showTip(event, `<b>${d.id}</b><br>Routes: ${d.degree}`))
    .on("mouseout", () => {
      link.attr("stroke-opacity", 0.7).attr("stroke", "#888");
      node.attr("opacity", 1);
      hideTip();
    });

  sim.on("tick", () => {
    nodes.forEach(d => {
      const r = rScale(d.degree) + 5;
      d.x = Math.max(r, Math.min(width - r, d.x));
      d.y = Math.max(r + 12, Math.min(height - r, d.y));
    });
    link.attr("x1", d => d.source.x).attr("y1", d => d.source.y)
        .attr("x2", d => d.target.x).attr("y2", d => d.target.y);
    node.attr("transform", d => `translate(${d.x},${d.y})`);
  });

  svg.append("text").attr("x", 10).attr("y", height - 28).attr("font-size", 12).attr("fill", "#555")
    .text("Link thickness = flights per week; node size = number of routes (degree)");
}

/* ---------- Task 4: Choropleth ---------- */
function task4(population, world) {
  const width = 960, height = 520;
  const svg = d3.select("#t4").append("svg").attr("width", width).attr("height", height);

  const popById = new Map(population.map(d => [d.id, d]));
  const [minP, maxP] = d3.extent(population, d => d.population_millions);
  const color = d3.scaleSequentialSqrt(d3.interpolateYlGnBu).domain([minP, maxP]);

  const projection = d3.geoNaturalEarth1().fitSize([width, height - 50], world);
  const path = d3.geoPath(projection);

  svg.append("g").selectAll("path").data(world.features).join("path")
    .attr("d", path)
    .attr("fill", d => popById.has(d.id) ? color(popById.get(d.id).population_millions) : "#d9d9d9")
    .attr("stroke", "#fff").attr("stroke-width", 0.5)
    .on("mouseover", function () { d3.select(this).raise().attr("stroke", "#000").attr("stroke-width", 1.8); })
    .on("mousemove", (event, d) => {
      const rec = popById.get(d.id);
      showTip(event, `<b>${d.properties.name}</b><br>` +
        (rec ? `Population: ${rec.population_millions} million` : "No data"));
    })
    .on("mouseout", function () { d3.select(this).attr("stroke", "#fff").attr("stroke-width", 0.5); hideTip(); });

  // legend (gradient bar with min and max labels)
  const lx = width / 2 - 150, ly = height - 35;
  const defs = svg.append("defs");
  const grad = defs.append("linearGradient").attr("id", "popGradient");
  d3.range(0, 1.01, 0.1).forEach(t => {
    const v = minP + t * (maxP - minP);
    grad.append("stop").attr("offset", `${t * 100}%`).attr("stop-color", color(v));
  });
  svg.append("rect").attr("x", lx).attr("y", ly).attr("width", 300).attr("height", 14).attr("fill", "url(#popGradient)").attr("stroke", "#999");
  svg.append("text").attr("x", lx).attr("y", ly + 28).attr("font-size", 12).attr("text-anchor", "start").text(`${minP} M (min)`);
  svg.append("text").attr("x", lx + 300).attr("y", ly + 28).attr("font-size", 12).attr("text-anchor", "end").text(`${maxP} M (max)`);
  svg.append("text").attr("x", lx - 10).attr("y", ly + 12).attr("font-size", 12).attr("text-anchor", "end").text("Population (millions)");
  svg.append("rect").attr("x", lx + 320).attr("y", ly).attr("width", 14).attr("height", 14).attr("fill", "#d9d9d9").attr("stroke", "#999");
  svg.append("text").attr("x", lx + 340).attr("y", ly + 12).attr("font-size", 12).text("No data");
}

/* ---------- Task 5: Pakistan point map ---------- */
function pakistanProjection(width, height) {
  return d3.geoMercator().center([69.5, 30.3]).scale(2600).translate([width / 2, height / 2]);
}

function task5(cities, world) {
  const width = 800, height = 700;
  const svg = d3.select("#t5").append("svg").attr("width", width).attr("height", height)
    .style("background", "#eaf3fb");
  const projection = pakistanProjection(width, height);
  const path = d3.geoPath(projection);

  svg.append("g").selectAll("path").data(world.features).join("path")
    .attr("d", path).attr("fill", d => d.id === "PAK" ? "#f4f1de" : "#ddd").attr("stroke", "#999");

  const r = d3.scaleSqrt().domain([0, d3.max(cities, d => d.pop)]).range([0, 45]);

  svg.append("g").selectAll("circle").data(cities).join("circle")
    .attr("cx", d => projection([d.lon, d.lat])[0])
    .attr("cy", d => projection([d.lon, d.lat])[1])
    .attr("r", d => r(d.pop))
    .attr("fill", "steelblue").attr("fill-opacity", 0.5).attr("stroke", "steelblue")
    .on("mousemove", (event, d) => showTip(event, `<b>${d.name}</b><br>Population: ${d.pop} million`))
    .on("mouseout", hideTip);

  svg.append("g").selectAll("text").data(cities.filter(d => d.pop > 1)).join("text")
    .attr("x", d => projection([d.lon, d.lat])[0] + (d.name === "Faisalabad" ? -(r(d.pop) + 4) : r(d.pop) + 4))
    .attr("text-anchor", d => d.name === "Faisalabad" ? "end" : "start")
    .attr("y", d => projection([d.lon, d.lat])[1] + 4)
    .attr("font-size", 13).attr("font-weight", "bold").attr("pointer-events", "none").text(d => d.name);

  svg.append("text").attr("x", 15).attr("y", 25).attr("font-size", 15).attr("font-weight", "bold")
    .text("Largest cities of Pakistan (circle area = population)");
}

/* ---------- Task 6: Combined map ---------- */
function task6(cities, flights, world) {
  const width = 800, height = 700;
  const svg = d3.select("#t6").append("svg").attr("width", width).attr("height", height)
    .style("background", "#eaf3fb");
  const projection = pakistanProjection(width, height);
  const path = d3.geoPath(projection);

  svg.append("g").selectAll("path").data(world.features).join("path")
    .attr("d", path).attr("fill", d => d.id === "PAK" ? "#f4f1de" : "#ddd").attr("stroke", "#999");

  // match routes to city coordinates
  const cityByName = new Map(cities.map(c => [c.name, c]));
  const routes = flights.map(f => ({ ...f, s: cityByName.get(f.source), t: cityByName.get(f.target) }))
    .filter(f => f.s && f.t);

  // degree -> hub
  const degree = new Map(cities.map(c => [c.name, 0]));
  routes.forEach(f => { degree.set(f.source, degree.get(f.source) + 1); degree.set(f.target, degree.get(f.target) + 1); });
  const isHub = d => degree.get(d.name) >= 4;

  const widthScale = d3.scaleLinear().domain(d3.extent(routes, d => d.flights)).range([1, 9]);
  const r = d3.scaleSqrt().domain([0, d3.max(cities, d => d.pop)]).range([0, 40]);
  const hubColor = "#d62728", normalColor = "#1f77b4";

  const pos = c => projection([c.lon, c.lat]);

  // routes first
  const routeSel = svg.append("g").selectAll("line").data(routes).join("line")
    .attr("x1", d => pos(d.s)[0]).attr("y1", d => pos(d.s)[1])
    .attr("x2", d => pos(d.t)[0]).attr("y2", d => pos(d.t)[1])
    .attr("stroke", "#555").attr("stroke-opacity", 0.55).attr("stroke-linecap", "round")
    .attr("stroke-width", d => widthScale(d.flights));
  routeSel.append("title").text(d => `${d.source} - ${d.target}: ${d.flights} flights/week`);

  // cities on top
  const cityG = svg.append("g").selectAll("g").data(cities).join("g")
    .attr("transform", d => `translate(${pos(d)})`);
  cityG.append("circle").attr("r", d => r(d.pop)).attr("fill", d => isHub(d) ? hubColor : normalColor)
    .attr("fill-opacity", 0.6).attr("stroke", d => isHub(d) ? hubColor : normalColor).attr("stroke-width", 1.5);
  cityG.append("text").attr("x", d => d.name === "Faisalabad" ? -(r(d.pop) + 4) : r(d.pop) + 4)
    .attr("text-anchor", d => d.name === "Faisalabad" ? "end" : "start").attr("y", 4).attr("font-size", 12)
    .attr("pointer-events", "none").text(d => d.name);

  cityG.on("mouseover", (event, d) => {
      const linked = new Set([d.name]);
      routeSel.attr("stroke-opacity", f => {
        const hit = f.source === d.name || f.target === d.name;
        if (hit) { linked.add(f.source); linked.add(f.target); }
        return hit ? 1 : 0.05;
      }).attr("stroke", f => (f.source === d.name || f.target === d.name) ? "#000" : "#555");
      cityG.attr("opacity", c => linked.has(c.name) ? 1 : 0.2);
      showTip(event, `<b>${d.name}</b><br>Population: ${d.pop} million<br>Routes: ${degree.get(d.name)}${isHub(d) ? " (hub)" : ""}`);
    })
    .on("mousemove", (event, d) => showTip(event,
      `<b>${d.name}</b><br>Population: ${d.pop} million<br>Routes: ${degree.get(d.name)}${isHub(d) ? " (hub)" : ""}`))
    .on("mouseout", () => {
      routeSel.attr("stroke-opacity", 0.55).attr("stroke", "#555");
      cityG.attr("opacity", 1);
      hideTip();
    });

  // legend explaining all four encodings
  const lg = svg.append("g").attr("transform", `translate(${width - 285},${height - 330})`);
  lg.append("rect").attr("width", 270).attr("height", 320).attr("fill", "#fff").attr("fill-opacity", 0.9).attr("stroke", "#999");
  lg.append("text").attr("x", 10).attr("y", 20).attr("font-weight", "bold").attr("font-size", 13).text("Legend");
  lg.append("text").attr("x", 10).attr("y", 40).attr("font-size", 12).text("Position = real city location");
  lg.append("text").attr("x", 10).attr("y", 62).attr("font-size", 12).text("Color = hub or not:");
  lg.append("circle").attr("cx", 20).attr("cy", 80).attr("r", 7).attr("fill", hubColor).attr("fill-opacity", 0.6);
  lg.append("text").attr("x", 34).attr("y", 84).attr("font-size", 12).text("Hub (4 or more routes)");
  lg.append("circle").attr("cx", 20).attr("cy", 102).attr("r", 7).attr("fill", normalColor).attr("fill-opacity", 0.6);
  lg.append("text").attr("x", 34).attr("y", 106).attr("font-size", 12).text("Not a hub (fewer than 4 routes)");
  lg.append("text").attr("x", 10).attr("y", 130).attr("font-size", 12).text("Circle size (area) = population:");
  [[1, 40], [4, 95], [16, 190]].forEach(([p, cx]) => {
    lg.append("circle").attr("cx", cx).attr("cy", 185).attr("r", r(p)).attr("fill", "none").attr("stroke", "#333");
    lg.append("text").attr("x", cx).attr("y", 238).attr("text-anchor", "middle").attr("font-size", 11).text(`${p} M`);
  });
  lg.append("text").attr("x", 10).attr("y", 262).attr("font-size", 12).text("Line width = flights per week:");
  [10, 40, 70].forEach((f, i) => {
    const x = 20 + i * 85;
    lg.append("line").attr("x1", x).attr("x2", x + 40).attr("y1", 281).attr("y2", 281)
      .attr("stroke", "#555").attr("stroke-width", widthScale(f));
    lg.append("text").attr("x", x + 20).attr("y", 306).attr("text-anchor", "middle").attr("font-size", 11).text(`${f}/wk`);
  });
}
